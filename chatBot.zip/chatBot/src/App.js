import React, { useEffect, useState } from 'react';
import Chatbot from 'react-chatbot-kit'
import './App.css';

import ActionProvider from './ActionProvider';
import MessageParser from './MessageParser';
import config from './config';
import MessengerCollapsedIcon from './components/Svg/MessengerCollapsedIcon'

import ChatBot from 'react-simple-chatbot';  // newly proposed chatBot package




function App() {

  const [isChatTextIconVisible, setIsChatTextIconVisible] = useState(false);

  function handleMinimizeIconClick(e) {
    setIsChatTextIconVisible(true);
   let chatBot = document.getElementsByClassName('react-chatbot-kit-chat-container')[0];
   chatBot.classList.add('hideChatBot')
  }

  const handleMessengerButtonClick = () => {
    setIsChatTextIconVisible(false);
    let chatBot = document.getElementsByClassName('react-chatbot-kit-chat-container')[0];
    chatBot.classList.remove('hideChatBot')
  }

  useEffect(()=>{
      let botHeader = document.getElementsByClassName('react-chatbot-kit-chat-header')[0];
      let minimizeIcon = document.createElement('span');
      minimizeIcon.innerHTML='<span>*</span>'
      minimizeIcon.className="minimizeIcon"
      botHeader.appendChild(minimizeIcon);
      botHeader.addEventListener('click',handleMinimizeIconClick);

      return ()=>{
        botHeader.removeEventListener('click',handleMinimizeIconClick);
      }
  },[])

  return (
    <div className="App">
      <header className="App-header">
        <div style={{position: 'relative', height:'100vh',width:'300px'}}>
        <Chatbot config={config} actionProvider={ActionProvider} messageParser={MessageParser} />
       {
         isChatTextIconVisible && 
          <button onClick={handleMessengerButtonClick} className="messengerCollapsedIcon">
              <MessengerCollapsedIcon/>
          </button>
       } 
       </div>
      </header>
    </div>
  );
}

export default App;
